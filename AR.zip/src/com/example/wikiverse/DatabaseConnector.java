// DatabaseConnector.java

package com.example.wikiverse;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseConnector
{

	private static final String DATABASE_NAME = "RoomDB";
	private SQLiteDatabase database;
	private final DatabaseOpenHelper databaseOpenHelper;

	//public constructor for DatabaseConnector
	public DatabaseConnector(Context context)
	{
		databaseOpenHelper = new DatabaseOpenHelper(context, DATABASE_NAME, null, 1);
	}

	//open the database connection
	public void open() throws SQLException
	{
		database = databaseOpenHelper.getWritableDatabase();
	}

	//close the database connection
	public void close()
	{
		if(database != null){database.close();}
	}

	//inserts a new contact in the database
	public void insertRoom(String buildingNumber, Integer roomNumber, String locationType, String locationName,
			Double longitude, Double latitude, Double altitude)
	{

		ContentValues newRoom = new ContentValues();
		newRoom.put("buildingNumber", buildingNumber);
		newRoom.put("roomNumber", roomNumber);
		newRoom.put("locationType", locationType);
		newRoom.put("locationName", locationName);
		newRoom.put("longitude", longitude);
		newRoom.put("latitude", latitude);
		newRoom.put("altitude", altitude);


		open(); //open the database
		database.insert("rooms", null, newRoom);
		close(); //close the database
	}


	public void updateRoom(long id,
			String buildingNumber, Integer roomNumber, String locationType, String locationName,
			Double longitude, Double latitude, Double altitude)
	{
		ContentValues existingRoom = new ContentValues();
		existingRoom.put("buildingNumber", buildingNumber);
		existingRoom.put("roomNumber", roomNumber);
		existingRoom.put("locationType", locationType);
		existingRoom.put("locationName", locationName);
		existingRoom.put("longitude", longitude);
		existingRoom.put("latitude", latitude);
		existingRoom.put("altitude", altitude);


		open(); //open the database
		database.update("rooms", existingRoom, "_id=" + id, null);
		close(); //close the database
	}


	public Cursor getAllRooms()
	{
		return database.query("rooms", new String[] {"_id", "roomNumber"}, null, null, null, null, "roomNumber");

	}


	public Cursor getRoom(long id)
	{
		return database.query("rooms", null, "_id=" + id, null, null, null, null);
	}


	public void deleteRoom(long id)
	{
		open(); //open the database
		database.delete("rooms", "_id=" + id, null);
		close(); //close the database
	}

	private class DatabaseOpenHelper extends SQLiteOpenHelper
	{

		public DatabaseOpenHelper(Context context, String name, CursorFactory factory, int version)
		{
			super(context, name, factory, version);
		}

		//creates the rooms table when the database is created
		@Override
		public void onCreate(SQLiteDatabase db)
		{
			//query to create a new table named rooms
			String query =
					"CREATE TABLE rooms" +
							"(_id integer primary key autoincrement," +
							"buildingNumber STRING," +
							"roomNumber INTEGER," +
							"locationType STRING," +
							"locationName STRING," +
							"longitude DOUBLE PRECISION," +
							"latitude DOUBLE PRECISION," +
							"altitude DOUBLE PRECISION);";

			db.execSQL(query);
		} //end method onCreate

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

	} //end class DatabaseOpenHelper
} //end class DatabaseConnector



